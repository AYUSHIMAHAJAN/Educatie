function on(){
    document.getElementById("nameField").style.maxHeight="0";
    document.getElementById("title").innerHTML="Sign In";
    signupBtn.classList.add("disable");
    signinBtn.classList.remove("disable");

}
function on2(){
    document.getElementById("nameField").style.maxHeight="60px";
    document.getElementById("title").innerHTML="Sign Up";
    signupBtn.classList.remove("disable");
    signinBtn.classList.add("disable");

}

function eyeclose(){
    if(document.getElementById("password").type=="password"){
        document.getElementById("password").type="text";
        document.getElementById("eyeicon").src="eye-open.png";
    }

    else{
        document.getElementById("password").type="password";
        document.getElementById("eyeicon").src="eye-close.png";
    }
}

